This is a python script for data cleaning
