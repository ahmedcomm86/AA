# AI_Research

put some stuff - all data for the project
